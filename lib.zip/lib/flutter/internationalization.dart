import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'ar', 'es'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? arText = '',
    String? esText = '',
  }) =>
      [enText, arText, esText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // SplashPage1
  {
    'qu4qvz13': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // LoginPage
  {
    'ygpkfzvy': {
      'en': 'Welcome Back',
      'ar': 'مرحبًا بعودتك',
      'es': 'Bienvenido de nuevo',
    },
    'if9a4fyq': {
      'en': 'Let\'s get started by filling out the form below.',
      'ar': 'لنبدأ بملء النموذج أدناه.',
      'es': 'Comencemos completando el formulario a continuación.',
    },
    'cuhg5h2k': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
      'es': 'Correo electrónico',
    },
    'qiz98qc1': {
      'en': 'Password',
      'ar': 'كلمة المرور',
      'es': 'Contraseña',
    },
    'jvavrjuj': {
      'en': 'Login',
      'ar': 'تسجيل الدخول',
      'es': 'Acceso',
    },
    'o07dn8b0': {
      'en': 'Please enter email id',
      'ar': 'الرجاء إدخال معرف البريد الإلكتروني',
      'es': 'Por favor ingrese la identificación de correo electrónico',
    },
    '5wmogy0o': {
      'en': 'Please enter valid email id',
      'ar': 'الرجاء إدخال البريد الإلكتروني الصحيح',
      'es': 'Por favor ingrese una identificación de correo electrónico válida',
    },
    '2ssulxuz': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    'emkt5zqf': {
      'en': 'Please enter  password ',
      'ar': 'الرجاء إدخال كلمة المرور',
      'es': 'Por favor, ingrese contraseña',
    },
    'evfcgber': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    '7ida6i7p': {
      'en': 'Or sign up with',
      'ar': 'أو قم بالتسجيل مع',
      'es': 'O regístrate con',
    },
    'mhoemhea': {
      'en': 'Already have an account? ',
      'ar': 'هل لديك حساب؟',
      'es': '¿Ya tienes una cuenta?',
    },
    'ytqlordy': {
      'en': 'Sign up',
      'ar': 'اشتراك',
      'es': 'Inscribirse',
    },
  },
  // NotificationPage
  {
    '3bafembr': {
      'en': 'Notification',
      'ar': 'إشعار',
      'es': 'Notificación',
    },
    'bjdj7m31': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // signupPage
  {
    '0p0b9pfj': {
      'en': 'Create a\nnew account\n',
      'ar': 'إنشاء\nحساب جديد',
      'es': 'Crear un\nnueva cuenta',
    },
    '89k4l8jl': {
      'en': 'Enter your complete details to \ncreate your account',
      'ar': 'أدخل التفاصيل الكاملة الخاصة بك ل\nأنشئ حسابك',
      'es': 'Ingresa tus datos completos para\nCrea tu cuenta',
    },
    '7v7ixvt3': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
      'es': 'Correo electrónico',
    },
    'wbbhdncd': {
      'en': 'Full Name',
      'ar': 'الاسم الكامل',
      'es': 'Nombre completo',
    },
    'bl0od0hs': {
      'en': 'Password',
      'ar': 'كلمة المرور',
      'es': 'Contraseña',
    },
    'xmmk259o': {
      'en': 'Confirm Password',
      'ar': 'تأكيد كلمة المرور',
      'es': 'confirmar Contraseña',
    },
    'myn8lzuh': {
      'en': 'Create Account',
      'ar': 'إنشاء حساب',
      'es': 'Crear una cuenta',
    },
    'bx6orwdq': {
      'en': 'Field is required',
      'ar': 'الحقل مطلوب',
      'es': 'Se requiere campo',
    },
    '1giem5jl': {
      'en': 'Please enter valid email id',
      'ar': 'الرجاء إدخال البريد الإلكتروني الصحيح',
      'es': 'Por favor ingrese una identificación de correo electrónico válida',
    },
    's548orc3': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    '5sgk3y5r': {
      'en': 'Field is required',
      'ar': 'الحقل مطلوب',
      'es': 'Se requiere campo',
    },
    'dhneoj2g': {
      'en': 'Please enter user name  ',
      'ar': 'الرجاء إدخال اسم المستخدم',
      'es': 'Por favor ingrese el nombre de usuario',
    },
    'biu293fk': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    'q8ve59sr': {
      'en': 'Please  enter password',
      'ar': 'الرجاء إدخال كلمة المرور',
      'es': 'Por favor, ingrese contraseña',
    },
    '1yvx607t': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    'pzxu4e9f': {
      'en': 'Please enter confirm password ',
      'ar': 'الرجاء إدخال تأكيد كلمة المرور',
      'es': 'Por favor ingrese confirmar contraseña',
    },
    'b69boic2': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    '3gieehle': {
      'en': 'Or sign up with',
      'ar': 'أو قم بالتسجيل مع',
      'es': 'O regístrate con',
    },
    'k5tkrarf': {
      'en': 'Already have an account? ',
      'ar': 'هل لديك حساب؟',
      'es': '¿Ya tienes una cuenta?',
    },
    'e2zk3fd9': {
      'en': 'Sign In',
      'ar': 'تسجيل الدخول',
      'es': 'Iniciar sesión',
    },
  },
  // HomePage
  {
    '41dhs01a': {
      'en': 'Search Here...',
      'ar': 'ابحث هنا...',
      'es': 'Busca aquí...',
    },
    '5evyq1ya': {
      'en': 'enter your search location',
      'ar': 'أدخل موقع البحث الخاص بك',
      'es': 'ingresa tu ubicación de búsqueda',
    },
    'ahrn63qh': {
      'en': 'Available cars',
      'ar': 'السيارة المتوفرة',
      'es': 'Coche disponible',
    },
    'azfqybrp': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
    '4rn1ny7d': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // vehicle_listing_page
  {
    '1f26sndv': {
      'en': 'Days',
      'ar': 'أيام',
      'es': 'Días',
    },
    '9nrrtl81': {
      'en': 'Hours',
      'ar': 'ساعات',
      'es': 'Horas',
    },
    '2mlzstcu': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'uklnmth2': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'xf936hfw': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    'w94vsybl': {
      'en': 'Vehicle Listing',
      'ar': 'قائمة المركبات',
      'es': 'Listado de vehículos',
    },
    'o9x1i06l': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // more_filter_page
  {
    'p6r3ar1p': {
      'en': 'More Filter',
      'ar': 'المزيد من التصفية',
      'es': 'Más filtro',
    },
    'ximtytd4': {
      'en': 'Location',
      'ar': 'موقع',
      'es': 'Ubicación',
    },
    '3ggt81oc': {
      'en': 'Search Here...',
      'ar': 'ابحث هنا...',
      'es': 'Busca aquí...',
    },
    'zqqn5a7c': {
      'en': 'Price',
      'ar': 'سعر',
      'es': 'Precio',
    },
    'e3g8k48q': {
      'en': 'Brand',
      'ar': 'ماركة',
      'es': 'Marca',
    },
    'c6515iqk': {
      'en': 'Maruti Suzuki',
      'ar': 'Maruti Suzuki',
      'es': 'Maruti Suzuki',
    },
    '47og9azx': {
      'en': 'Renault',
      'ar': 'Renault',
      'es': 'Renault',
    },
    'x7w4hzte': {
      'en': 'Hyundai',
      'ar': 'Hyundai',
      'es': 'Hyundai',
    },
    '031fyc8d': {
      'en': 'Toyota',
      'ar': 'Toyota',
      'es': 'Toyota',
    },
    'v11t7y1t': {
      'en': 'KIA',
      'ar': 'KIA',
      'es': 'KIA',
    },
    'txfxon3g': {
      'en': 'Tata Motars',
      'ar': 'Tata Motars',
      'es': 'Tata Motars',
    },
    'wxnjayuj': {
      'en': 'Mahindra ',
      'ar': 'Mahindra ',
      'es': 'Mahindra ',
    },
    'hmsjzk0s': {
      'en': 'Honda',
      'ar': 'Honda',
      'es': 'Honda',
    },
    '86l9nq6i': {
      'en': 'Please select band',
      'ar': '',
      'es': '',
    },
    'ge0r9f4r': {
      'en': 'Search for an item...',
      'ar': '',
      'es': '',
    },
    '0um1s2zd': {
      'en': 'Vehicle Type',
      'ar': 'نوع السيارة',
      'es': 'tipo de vehiculo',
    },
    'lct9bt0b': {
      'en': 'SUV',
      'ar': 'SUV',
      'es': '',
    },
    '0y4waitz': {
      'en': 'MUV',
      'ar': '',
      'es': '',
    },
    '77fhwwp7': {
      'en': 'Luxury',
      'ar': 'Luxury',
      'es': 'Luxury',
    },
    'wpvg3uqg': {
      'en': 'Sports',
      'ar': 'Sports',
      'es': 'Sports',
    },
    'p6oi6gzr': {
      'en': 'Please select vehicle type',
      'ar': '',
      'es': '',
    },
    'w1bbj03s': {
      'en': 'Search for an item...',
      'ar': '',
      'es': '',
    },
    'ldt9x460': {
      'en': 'Fuel Type',
      'ar': 'نوع الوقود',
      'es': 'Tipo de combustible',
    },
    'wg341w1p': {
      'en': 'Disel',
      'ar': '',
      'es': '',
    },
    '6sti7o4o': {
      'en': 'Disel',
      'ar': 'Disel',
      'es': 'Disel',
    },
    'mzxaq16c': {
      'en': 'Petrol',
      'ar': 'Petrol',
      'es': 'Petrol',
    },
    'z0m3r4h7': {
      'en': 'EV',
      'ar': 'EV',
      'es': 'EV',
    },
    'uyodmq21': {
      'en': 'CNG',
      'ar': 'CNG',
      'es': 'CNG',
    },
    'pghdrqrf': {
      'en': 'Please select Fule type',
      'ar': '',
      'es': '',
    },
    '39qlp78b': {
      'en': 'Search for an item...',
      'ar': '',
      'es': '',
    },
    '09wgunbd': {
      'en': 'Days And Hourly',
      'ar': 'باب الطاقة',
      'es': 'Puerta eléctrica',
    },
    '63rynpmm': {
      'en': 'Days',
      'ar': '',
      'es': '',
    },
    'li5iqc87': {
      'en': 'Days',
      'ar': 'Days',
      'es': 'Days',
    },
    '4hc07c3a': {
      'en': 'Hourly',
      'ar': 'Hourly',
      'es': 'Hourly',
    },
    'ic9zni57': {
      'en': 'Please select days and hourly',
      'ar': '',
      'es': '',
    },
    'cvvo9laq': {
      'en': 'Search for an item...',
      'ar': '',
      'es': '',
    },
    'g0u3cva6': {
      'en': 'Apply',
      'ar': 'يتقدم',
      'es': 'Aplicar',
    },
    '54vofrya': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // product_detail_page
  {
    '1wk0pwmi': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'gdgk4la9': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'hv7ydtqz': {
      'en': 'Features',
      'ar': 'سمات',
      'es': 'Características',
    },
    'y90sqru4': {
      'en': 'Automatic transmission: Yes',
      'ar': 'ناقل الحركة الأوتوماتيكي: نعم',
      'es': 'Transmisión automática: Sí',
    },
    'mk4g2ktn': {
      'en': 'Descriptions',
      'ar': 'الأوصاف',
      'es': 'Descripciones',
    },
    'ri8keepz': {
      'en': 'Specification',
      'ar': 'تخصيص',
      'es': 'Especificación',
    },
    '9ljxt6nm': {
      'en': 'Where to find',
      'ar': 'أين تجد',
      'es': 'Donde encontrar',
    },
    'pvhvrom9': {
      'en': 'Similar Vehicles ',
      'ar': 'مركبات مماثلة',
      'es': 'Vehículos similares',
    },
    'uc5oqgba': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'g5ane3oy': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'dee2pi5u': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    '30q5685b': {
      'en': 'Rent It',
      'ar': 'استأجرها',
      'es': 'Alquilalo',
    },
    'nlaxqzbk': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // your_currentBooking_page
  {
    'zmr4vt9t': {
      'en': 'Current Booking',
      'ar': 'الحجز الحالي',
      'es': 'Reserva actual',
    },
    'g3baa7fb': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'ibfzcjjx': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    '882rxjud': {
      'en': 'Price',
      'ar': '',
      'es': '',
    },
    '3dfiveih': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    't6bazqfn': {
      'en': 'No Booking Available !',
      'ar': 'لا يوجد حجز متاح!',
      'es': '¡No hay reservas disponibles!',
    },
    'zt1l5kzn': {
      'en': 'History',
      'ar': 'تاريخ',
      'es': 'Historia',
    },
    '847bm6he': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'v2nw6ctr': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'ul0cxoo5': {
      'en': 'Price',
      'ar': '',
      'es': '',
    },
    '963r5h1i': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    'cwi7jaad': {
      'en': 'No Booking Available !',
      'ar': 'لا يوجد حجز متاح!',
      'es': '¡No hay reservas disponibles!',
    },
    '64j4t9wx': {
      'en': 'Booking',
      'ar': 'الحجز',
      'es': 'Reserva',
    },
    'icu4qvrc': {
      'en': 'Bookings',
      'ar': 'الحجوزات',
      'es': 'Reservaciones',
    },
  },
  // address_page
  {
    'u6swov4v': {
      'en': 'Add New Addrress',
      'ar': 'إضافة عنوان جديد',
      'es': 'Agregar nueva dirección',
    },
    'uvib30ms': {
      'en': 'Address',
      'ar': 'عنوان',
      'es': 'DIRECCIÓN',
    },
    'tizrv6dy': {
      'en': 'Dewas',
      'ar': 'ديواس',
      'es': 'Dewas',
    },
    '4mvd6mv3': {
      'en': '34, Mahaweer Nagar, Dewas',
      'ar': '34، محوير نجار، ديواس',
      'es': '34, Mahaweer Nagar, Dewas',
    },
    'o5awb2uw': {
      'en': '(+91) 98266 98050',
      'ar': '(+91) 98266 98050',
      'es': '(+91) 98266 98050',
    },
    'amveo663': {
      'en': 'Zip code:',
      'ar': 'الرمز البريدي:',
      'es': 'Código postal:',
    },
    'uugrk14b': {
      'en': '455001',
      'ar': '455001',
      'es': '455001',
    },
    'dgcvrapm': {
      'en': 'Set Address Defaut  ',
      'ar': 'تعيين العنوان الافتراضي',
      'es': 'Establecer dirección predeterminada',
    },
    '7qy0hda4': {
      'en': 'Dewas',
      'ar': 'ديواس',
      'es': 'Dewas',
    },
    'it291rmd': {
      'en': '34, Mahaweer Nagar, Dewas',
      'ar': '34، محوير نجار، ديواس',
      'es': '34, Mahaweer Nagar, Dewas',
    },
    'h6srezlr': {
      'en': '(+91) 98266 98050',
      'ar': '(+91) 98266 98050',
      'es': '(+91) 98266 98050',
    },
    'gxpjs2w5': {
      'en': 'Zip code:',
      'ar': 'الرمز البريدي:',
      'es': 'Código postal:',
    },
    '3h0wfkne': {
      'en': '455001',
      'ar': '455001',
      'es': '455001',
    },
    'p2qfsnb8': {
      'en': 'Set Address Defaut ',
      'ar': 'تعيين العنوان الافتراضي',
      'es': 'Establecer dirección predeterminada',
    },
    'g55e4ia6': {
      'en': 'Address',
      'ar': 'عنوان',
      'es': 'DIRECCIÓN',
    },
    'rc44sz8v': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // payment_method_page
  {
    'o1hts0bx': {
      'en': 'Add New Card',
      'ar': 'إضافة بطاقة جديدة',
      'es': 'Agregar nueva tarjeta',
    },
    '7tzgolfc': {
      'en': 'Credit cards',
      'ar': 'بطاقات الائتمان',
      'es': 'Tarjetas de crédito',
    },
    'aeyravv1': {
      'en': '**** **** **** 1234',
      'ar': '**** **** **** 1234',
      'es': '**** **** **** 1234',
    },
    'l66u8s7u': {
      'en': 'VISA Card',
      'ar': 'بطاقة فيزا',
      'es': 'Tarjeta Visa',
    },
    '3w7abgxq': {
      'en': '**** **** **** 1234',
      'ar': '**** **** **** 1234',
      'es': '**** **** **** 1234',
    },
    'ffjn81aw': {
      'en': 'Master Card',
      'ar': 'بطاقة ماستر بطاقة ائتمان',
      'es': 'Tarjeta maestra',
    },
    'naleqxks': {
      'en': '**** **** **** 1234',
      'ar': '**** **** **** 1234',
      'es': '**** **** **** 1234',
    },
    '58et1ax4': {
      'en': 'Paypal Card',
      'ar': 'بطاقة باي بال',
      'es': 'Tarjeta Paypal',
    },
    'cdssq4h4': {
      'en': 'Payment Methods',
      'ar': 'طرق الدفع',
      'es': 'Métodos de pago',
    },
    'v716gt1l': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // Information_page
  {
    'dp13yjqj': {
      'en': 'Information',
      'ar': 'معلومة',
      'es': 'Información',
    },
    'b2k3drgb': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // message_page
  {
    '37ob9eig': {
      'en': 'Message',
      'ar': 'رسالة',
      'es': 'Mensaje',
    },
    'jjuhxx69': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // location_page
  {
    '7z9o676i': {
      'en': 'Select Location',
      'ar': 'اختر موقعا',
      'es': 'Seleccionar Ubicación',
    },
    'gsymxful': {
      'en': 'Location',
      'ar': '',
      'es': '',
    },
    'p2rkghtj': {
      'en': 'Location',
      'ar': 'طريق',
      'es': 'Ruta',
    },
    'brj850v2': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // booking_page
  {
    '6pl2lxl3': {
      'en': 'Self',
      'ar': '',
      'es': '',
    },
    'v8no0oyb': {
      'en': 'Self',
      'ar': 'الذات',
      'es': 'Ser',
    },
    'jz6j8hga': {
      'en': 'Driver',
      'ar': 'سائق',
      'es': 'Conductor',
    },
    'gcruivme': {
      'en': '\$',
      'ar': '',
      'es': '',
    },
    'o8e8rhpu': {
      'en': ' Per Days',
      'ar': '',
      'es': '',
    },
    'sobzzdfw': {
      'en': ' ',
      'ar': '',
      'es': '',
    },
    'x1lc4q5d': {
      'en': '\$',
      'ar': '',
      'es': '',
    },
    's3b6u5bv': {
      'en': ' Per',
      'ar': '',
      'es': '',
    },
    'pvvsz70d': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'aafmr9y1': {
      'en': 'Option 1',
      'ar': 'الخيار 1',
      'es': 'Opción 1',
    },
    '7adfhanl': {
      'en': 'Please select pickup location',
      'ar': 'الرجاء تحديد موقع الالتقاط',
      'es': 'Por favor seleccione el lugar de recogida',
    },
    '2t3olczu': {
      'en': 'Search for an item...',
      'ar': 'البحث عن عنصر...',
      'es': 'Buscar un artículo...',
    },
    'gnnbki8q': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '5ix4b3hr': {
      'en': 'Option 1',
      'ar': 'الخيار 1',
      'es': 'Opción 1',
    },
    '6bgu8ex7': {
      'en': 'Please select dropoff location',
      'ar': 'الرجاء تحديد موقع الالتقاط',
      'es': 'Por favor seleccione el lugar de recogida',
    },
    'v89jtu1y': {
      'en': 'Search for an item...',
      'ar': 'البحث عن عنصر...',
      'es': 'Buscar un artículo...',
    },
    'nve5nwq1': {
      'en': 'Name of Rented',
      'ar': 'اسم المستأجرة',
      'es': 'Nombre del Alquilado',
    },
    'pli178ke': {
      'en': 'Please enter name',
      'ar': '',
      'es': '',
    },
    '7kixyhdg': {
      'en': 'Phone Number',
      'ar': 'رقم التليفون',
      'es': 'Número de teléfono',
    },
    '9fwpvtje': {
      'en': 'Please enter contact Number',
      'ar': '',
      'es': '',
    },
    '6b8vp6f5': {
      'en': 'Start date',
      'ar': 'تاريخ البدء',
      'es': 'Fecha de inicio',
    },
    'p878gseq': {
      'en': 'Start time',
      'ar': 'تاريخ البدء',
      'es': 'Fecha de inicio',
    },
    '1ui0h2nb': {
      'en': 'End date',
      'ar': 'تاريخ الانتهاء',
      'es': 'Fecha final',
    },
    '062bdg35': {
      'en': 'End time',
      'ar': 'تاريخ الانتهاء',
      'es': 'Fecha final',
    },
    'uwxzfxa2': {
      'en': 'License photo back and fornt',
      'ar': 'صورة الترخيص من الخلف والأمام',
      'es': 'Foto de licencia de ida y vuelta',
    },
    'b9dlagdz': {
      'en': 'Rental  Fees',
      'ar': 'تأجير ريس',
      'es': 'Alquiler Fees',
    },
    '4hvdgqis': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'qj2u90vy': {
      'en': 'driver',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'le6zzjtl': {
      'en': ' ',
      'ar': '600 دولار',
      'es': '\$600',
    },
    '89j9atll': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'p5ik7die': {
      'en': 'days',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'b44laoxv': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    '4iixpq4v': {
      'en': ' houly',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'nx5oz5zu': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    'kvtmofp3': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    'p8jtyhqy': {
      'en': 'I accept terms of service',
      'ar': 'أوافق على شروط الخدمة',
      'es': 'Acepto los términos de servicio',
    },
    'konc25ih': {
      'en': 'Book',
      'ar': 'كتاب',
      'es': 'Libro',
    },
    'rfbijtbs': {
      'en': 'Booking',
      'ar': 'الحجز',
      'es': 'Reserva',
    },
    'r5nsh2jf': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // edit_profile
  {
    'i4u53ivf': {
      'en': 'Edit Page',
      'ar': 'تعديل الصفحة',
      'es': 'Editar página',
    },
    '4gks486y': {
      'en': 'Full Name',
      'ar': 'الاسم الكامل',
      'es': 'Nombre completo',
    },
    't8xpkwki': {
      'en': 'Enter your full name',
      'ar': 'أدخل اسمك الكامل',
      'es': 'Introduce tu nombre completo',
    },
    'tgovzoq7': {
      'en': 'Email Address',
      'ar': 'عنوان البريد الإلكتروني',
      'es': 'Dirección de correo electrónico',
    },
    '5mrcu7r1': {
      'en': 'Enter your email address',
      'ar': 'أدخل عنوان بريدك الالكتروني',
      'es': 'Introduce tu dirección de correo electrónico',
    },
    'x49fyvee': {
      'en': 'Phone Number',
      'ar': 'رقم التليفون',
      'es': 'Número de teléfono',
    },
    'bqy57d8r': {
      'en': 'Enter your phone number',
      'ar': 'أدخل رقم هاتفك',
      'es': 'Ingrese su número telefónico',
    },
    'z5ykg1jz': {
      'en': 'Save Changes',
      'ar': 'حفظ التغييرات',
      'es': 'Guardar cambios',
    },
  },
  // confirmation_page
  {
    'dx0o2bhy': {
      'en': 'Please  Review Your Request and confrim',
      'ar': 'يرجى مراجعة طلبك والتأكيد',
      'es': 'Por favor revise su solicitud y confirme',
    },
    'vy3zwxy0': {
      'en': '\$',
      'ar': '',
      'es': '',
    },
    'g8u9edbp': {
      'en': 'Full Name',
      'ar': 'الاسم الكامل',
      'es': 'Nombre completo',
    },
    'xck1b5m9': {
      'en': 'Name',
      'ar': 'اسم',
      'es': 'Nombre',
    },
    'neqmcvn4': {
      'en': 'Mobile Number',
      'ar': 'رقم الهاتف المحمول',
      'es': 'Número de teléfono móvil',
    },
    '8cgwoodc': {
      'en': 'Mobile Number',
      'ar': 'رقم الهاتف المحمول',
      'es': 'Número de teléfono móvil',
    },
    'q0u6kl6c': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
      'es': 'Correo electrónico',
    },
    'n6r3zyp1': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
      'es': 'Correo electrónico',
    },
    'mlrivcx6': {
      'en': 'Pickup Address',
      'ar': 'الاستلام والعودة',
      'es': 'Recogida y devolución',
    },
    '81teod8g': {
      'en': 'Return Address',
      'ar': 'الاستلام والعودة',
      'es': 'Recogida y devolución',
    },
    'qs8elic5': {
      'en': 'Rental  Rees',
      'ar': 'تأجير ريس',
      'es': 'Alquiler Rees',
    },
    'cm6xinmt': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'cc8dnbt7': {
      'en': 'driver',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'm60be12x': {
      'en': ' ',
      'ar': '600 دولار',
      'es': '\$600',
    },
    'oiv8z3y9': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'npjj1f7n': {
      'en': 'days',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'tfodefb4': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    '4tnjexl6': {
      'en': 'Rental  Rees',
      'ar': 'تأجير ريس',
      'es': 'Alquiler Rees',
    },
    'a4vmimgx': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    'meoh2eql': {
      'en': 'driver',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    '10teyk1y': {
      'en': ' ',
      'ar': '600 دولار',
      'es': '\$600',
    },
    'x6nm0quf': {
      'en': 'Total of ',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    '805xt1d3': {
      'en': 'hourly',
      'ar': 'إجمالي 3 أيام',
      'es': 'Total de 3 días',
    },
    '4geu19oq': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    'i2sq1i0t': {
      'en': ' \$',
      'ar': '800 دولار',
      'es': '\$800',
    },
    '3nsfzryp': {
      'en': 'Payment method',
      'ar': 'طريقة الدفع او السداد',
      'es': 'Método de pago',
    },
    'k90w4e0g': {
      'en': '**** **** **** 1234',
      'ar': '**** **** **** 1234',
      'es': '**** **** **** 1234',
    },
    'qsa14vpn': {
      'en': 'Pay now',
      'ar': 'ادفع الآن',
      'es': 'Pagar ahora',
    },
    'fub301no': {
      'en': 'Pay at Pick-up',
      'ar': 'الدفع عند الاستلام',
      'es': 'Pagar al recoger',
    },
    'pzxgxutd': {
      'en': 'Confrimation',
      'ar': 'تأكيد',
      'es': 'Confirmación',
    },
    '0khsnznw': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // booking_successfully_page
  {
    '8sk7o7zk': {
      'en': 'Booking Successfully',
      'ar': 'تم الحجز بنجاح',
      'es': 'Reserva exitosa',
    },
    'c8p568dk': {
      'en':
          'You\'ve booked car successfully. Go to My booking for more booking detail.',
      'ar': 'لقد قمت بحجز السيارة بنجاح. انتقل إلى حجزي لمزيد من تفاصيل الحجز.',
      'es':
          'Has reservado el coche con éxito. Vaya a Mi reserva para obtener más detalles sobre la reserva.',
    },
    'v344iihr': {
      'en': 'Summary',
      'ar': 'ملخص',
      'es': 'Resumen',
    },
    'n8oog2rh': {
      'en': 'Car',
      'ar': 'سيارة',
      'es': 'Auto',
    },
    'nhpxkroy': {
      'en': 'Trip pickup ',
      'ar': 'الاستلام والعودة',
      'es': 'recogida y devolución',
    },
    '8ryhnx7i': {
      'en': 'Return address',
      'ar': 'الاستلام والعودة',
      'es': 'recogida y devolución',
    },
    'nbn06gp4': {
      'en': 'Trip start date',
      'ar': 'تاريخ الرحلة',
      'es': 'Fecha de viaje',
    },
    'mbowpdmn': {
      'en': 'Return date',
      'ar': 'تاريخ الرحلة',
      'es': 'Fecha de viaje',
    },
    'dur2igv0': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    'wbgpvwye': {
      'en': ' \$',
      'ar': '800 دولار',
      'es': '\$800',
    },
    'feux1yxi': {
      'en': 'Go To Home',
      'ar': 'اذهب إلى المنزل',
      'es': 'Ir a casa',
    },
    'mupzwz9h': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // add_my_payment_page
  {
    'f7a6wnt3': {
      'en': 'Pay',
      'ar': 'يدفع',
      'es': 'Pagar',
    },
    'e353pjnp': {
      'en': 'Paymnet',
      'ar': 'شبكة الدفع',
      'es': 'Pago',
    },
    'u5n0y2mr': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // support_page
  {
    '1cy3vp12': {
      'en': 'Welcome to support',
      'ar': 'مرحبا بكم في الدعم',
      'es': 'Bienvenido a apoyar',
    },
    'yayjowch': {
      'en': 'Submit a Ticket',
      'ar': 'تسجيل التذكرة',
      'es': 'Envía un boleto',
    },
    'd64ticys': {
      'en': 'User Name',
      'ar': 'اسم المستخدم',
      'es': 'Nombre de usuario',
    },
    'yd9rmtek': {
      'en': 'Email',
      'ar': 'بريد إلكتروني',
      'es': 'Correo electrónico',
    },
    '0g085y2a': {
      'en': 'Contact',
      'ar': 'اتصال',
      'es': 'Contacto',
    },
    '64cwuku8': {
      'en': 'Short Description of what is going on...',
      'ar': 'وصف مختصر لما يحدث...',
      'es': 'Breve descripción de lo que está pasando...',
    },
    'ja010245': {
      'en': 'Submit',
      'ar': 'يُقدِّم',
      'es': 'Entregar',
    },
    'vanz5ki4': {
      'en': 'Submit Ticket',
      'ar': 'قدم التذكرة',
      'es': 'Enviar ticket',
    },
    'gnud9hpr': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // booking_History_List
  {
    'xf4nlb3i': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    '04krq0p0': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'jujcrcje': {
      'en': 'Price',
      'ar': '',
      'es': '',
    },
    't6khy8tq': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    'u84f0ob1': {
      'en': 'History',
      'ar': 'تاريخ',
      'es': 'Historia',
    },
    'vpsu3vv9': {
      'en': 'Wish List',
      'ar': 'قائمة الرغبات',
      'es': 'Lista de deseos',
    },
  },
  // booking_detail_page
  {
    'z5umyfkd': {
      'en': 'Booking Details',
      'ar': 'تفاصيل الحجز',
      'es': 'Detalles de la reserva',
    },
    '1dbmam87': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'x7qgqosd': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'sac1yk3s': {
      'en': 'Driver Detail',
      'ar': 'تفاصيل السائق',
      'es': 'Detalle del conductor',
    },
    'rpgy9djv': {
      'en': 'Driver Name',
      'ar': 'اسم السائق',
      'es': 'Nombre del conductor',
    },
    '0tsg3xre': {
      'en': 'jogn tomer',
      'ar': 'برامود تومر',
      'es': 'tomer pramod',
    },
    'hffbxk2l': {
      'en': 'Driver Phone Number',
      'ar': 'رقم هاتف السائق',
      'es': 'Número de teléfono del conductor',
    },
    'p3yu5y5n': {
      'en': '+91 8827904769',
      'ar': '+91 8827904764',
      'es': '+91 8827904764',
    },
    'fpl9ns3f': {
      'en': 'Car Seats',
      'ar': 'مقاعد السيارة',
      'es': 'Asientos de carro',
    },
    'lcww4gsd': {
      'en': 'Descriptions',
      'ar': 'الأوصاف',
      'es': 'Descripciones',
    },
    '210seo17': {
      'en': 'Features',
      'ar': 'سمات',
      'es': 'Características',
    },
    'vs47b3oz': {
      'en': 'Automatic transmission: Yes',
      'ar': 'ناقل الحركة الأوتوماتيكي: نعم',
      'es': 'Transmisión automática: Sí',
    },
    'oi63dzrs': {
      'en': 'Pickup and Return',
      'ar': 'الاستلام والعودة',
      'es': 'Recogida y devolución',
    },
    'wf9mvwnl': {
      'en': 'Pickup and Return',
      'ar': 'الاستلام والعودة',
      'es': 'Recogida y devolución',
    },
    'yfakuji7': {
      'en': 'Rental  Amount',
      'ar': 'مبلغ الإيجار',
      'es': 'Monto del alquiler',
    },
    'aalh5yj0': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    '57a4seeo': {
      'en': ' \$',
      'ar': '',
      'es': '',
    },
    'akx9iwst': {
      'en': 'Cancel',
      'ar': 'يلغي',
      'es': 'Cancelar',
    },
    'skx8itm3': {
      'en': 'Pick-up',
      'ar': 'يلتقط',
      'es': 'Levantar',
    },
    'uc8bj374': {
      'en': 'On Road',
      'ar': 'على الطريق',
      'es': 'En la carretera',
    },
    'lifp86mm': {
      'en': 'Deliver',
      'ar': 'يسلم',
      'es': 'Entregar',
    },
    'ho6wpn9f': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // change_password_page
  {
    'wi3e3bo4': {
      'en': 'Current Password',
      'ar': 'كلمة السر الحالية',
      'es': 'Contraseña actual',
    },
    'jtz7c2zs': {
      'en': 'New Password',
      'ar': 'كلمة المرور الجديدة',
      'es': 'Nueva contraseña',
    },
    'djim67wx': {
      'en': 'Confirm Password',
      'ar': 'تأكيد كلمة المرور',
      'es': 'confirmar Contraseña',
    },
    'uowtj27v': {
      'en': 'Please  enter your old password.',
      'ar': 'الرجاء إدخال كلمة المرور القديمة.',
      'es': 'Por favor ingrese su antigua contraseña.',
    },
    '7lkd8cya': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    'klck5kp1': {
      'en': 'Please enter your new password',
      'ar': 'الرجاء إدخال كلمة المرور الجديدة',
      'es': 'Por favor ingrese su nueva contraseña',
    },
    '7wwpw48z': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    'y77y2cbb': {
      'en': 'Please enter your confirm password',
      'ar': 'الرجاء إدخال تأكيد كلمة المرور الخاصة بك',
      'es': 'Por favor ingrese su contraseña de confirmación',
    },
    'skya6dw6': {
      'en': 'Please choose an option from the dropdown',
      'ar': 'يرجى اختيار خيار من القائمة المنسدلة',
      'es': 'Por favor elija una opción del menú desplegable',
    },
    '248m3bha': {
      'en': 'Save Changes',
      'ar': 'حفظ التغييرات',
      'es': 'Guardar cambios',
    },
    'pmnplsci': {
      'en': 'Change Password',
      'ar': 'تغيير كلمة المرور',
      'es': 'Cambiar la contraseña',
    },
  },
  // your_favouriteList_page
  {
    'wr75d95l': {
      'en': 'Favorite ',
      'ar': 'مفضل',
      'es': 'Favorito',
    },
    'rswwto66': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'e8zle783': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    '0uuzgdpj': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    '5k1k1q0n': {
      'en': 'Favorite',
      'ar': 'مفضل',
      'es': 'Favorito',
    },
  },
  // histroy_detail_page
  {
    'aexfonwp': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'irweqdj5': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'mf4o3v9b': {
      'en': 'Review',
      'ar': 'مراجعة',
      'es': 'Revisar',
    },
    '0fkd0m1k': {
      'en': 'Driver Detail',
      'ar': 'تفاصيل السائق',
      'es': 'Detalle del conductor',
    },
    'jin2pifz': {
      'en': 'Driver Name',
      'ar': 'اسم السائق',
      'es': 'Nombre del conductor',
    },
    'i65ey8f8': {
      'en': 'John tomer',
      'ar': 'برامود تومر',
      'es': 'tomer pramod',
    },
    'z9ac1rtp': {
      'en': 'Driver Phone Number',
      'ar': 'رقم هاتف السائق',
      'es': 'Número de teléfono del conductor',
    },
    'qwtjokhl': {
      'en': '+91 8827904769',
      'ar': '+91 8827904764',
      'es': '+91 8827904764',
    },
    '880638lp': {
      'en': 'Availability',
      'ar': 'التوفر',
      'es': 'Disponibilidad',
    },
    'h87bx4ig': {
      'en': 'Minimum Days: 2 Days',
      'ar': 'الحد الأدنى للأيام: يومين',
      'es': 'Días mínimos: 2 días',
    },
    '21h5gnww': {
      'en': 'Car Seats',
      'ar': 'مقاعد السيارة',
      'es': 'Asientos de carro',
    },
    '1ag8ozwz': {
      'en': 'Descriptions',
      'ar': 'الأوصاف',
      'es': 'Descripciones',
    },
    'qczvar83': {
      'en': 'Features',
      'ar': 'سمات',
      'es': 'Características',
    },
    'lochcfgh': {
      'en': 'Location',
      'ar': 'موقع',
      'es': 'Ubicación',
    },
    'a5diebah': {
      'en': 'Automatic transmission: Yes',
      'ar': 'ناقل الحركة الأوتوماتيكي: نعم',
      'es': 'Transmisión automática: Sí',
    },
    'airbags': {
      'en': 'Airbags: 6 bags ',
      'ar': 'وسائد هوائية - 6 أكياس',
      'es': 'airbags: 6 bolsas',
    },
    'safety': {
      'en': 'Safety rating - 5 star in global NCAP ',
      'ar': 'تصنيف السلامة - 5 نجوم في NCAP العالمي',
      'es': 'Calificación de seguridad: 5 estrellas en NCAP global',
    },
    'vmuwnnz6': {
      'en': 'Pickup Address',
      'ar': 'عنوان الاستلام',
      'es': 'Dirección de entrega',
    },
    '0ril64r9': {
      'en': 'Pickup and Return',
      'ar': 'الاستلام والعودة',
      'es': 'Recogida y devolución',
    },
    'q36z8wq8': {
      'en': 'Rental  Fee',
      'ar': 'رسوم الإيجار',
      'es': 'Precio de renta',
    },
    'ie29xnxc': {
      'en': 'Total fees',
      'ar': 'الرسوم الكلية',
      'es': 'Tarifas totales',
    },
    '88euir1v': {
      'en': ' \$',
      'ar': '800 دولار',
      'es': '\$800',
    },
    'bhxchf0e': {
      'en': 'Booking Status',
      'ar': 'وضع الحجز',
      'es': 'Estado de la reservación',
    },
    '8vsmwv6i': {
      'en': 'History Details',
      'ar': 'تفاصيل التاريخ',
      'es': 'Detalles de la historia',
    },
    '0x5o6vbg': {
      'en': 'Home',
      'ar': 'بيت',
      'es': 'Hogar',
    },
  },
  // settings_page
  {
    'bwhpeicr': {
      'en': 'Settings',
      'ar': 'إعدادات',
      'es': 'Ajustes',
    },
    'sgwvfgwt': {
      'en': '         ',
      'ar': '',
      'es': '',
    },
    'p7fixm5n': {
      'en': 'Mode',
      'ar': 'لاوناج',
      'es': 'Lavadero',
    },
    '69inanq5': {
      'en': 'Change Password',
      'ar': 'تغيير كلمة المرور',
      'es': 'Cambiar la contraseña',
    },
    'mcmg3n10': {
      'en': 'Edit Profile',
      'ar': 'تعديل الملف الشخصي',
      'es': 'Editar perfil',
    },
    'g4vzf15u': {
      'en': 'Contact Us',
      'ar': 'اتصل بنا',
      'es': 'Contáctenos',
    },
    'olr7jsxh': {
      'en': 'Language',
      'ar': 'لاوناج',
      'es': 'Lavadero',
    },
    'dwut51nl': {
      'en': 'Account Delete',
      'ar': 'حذف الحساب',
      'es': 'Eliminar cuenta',
    },
    '837x3ooi': {
      'en': 'Logout',
      'ar': 'تسجيل خروج',
      'es': 'Cerrar sesión',
    },
    '39k73xfz': {
      'en': 'Settings',
      'ar': 'إعدادات',
      'es': 'Ajustes',
    },
  },
  // search_page
  {
    '514qv0xu': {
      'en': 'Search',
      'ar': 'يبحث',
      'es': 'Buscar',
    },
    'yy1kqgyl': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    'lp4rn0k6': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    'yfptwmsw': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
    '2sk738dg': {
      'en': 'Home',
      'ar': '',
      'es': '',
    },
  },
  // language_page
  {
    'lu5f2dgm': {
      'en': 'English',
      'ar': 'English',
      'es': 'English',
    },
    '0ike59t8': {
      'en': 'Arabic',
      'ar': 'Arabic',
      'es': 'Arabic',
    },
    '19zferan': {
      'en': 'Spanish',
      'ar': 'Spanish',
      'es': 'Spanish',
    },
    'n64id622': {
      'en': 'Language',
      'ar': 'لغة',
      'es': 'Idioma',
    },
    'jcz9z1d6': {
      'en': 'Home',
      'ar': '',
      'es': '',
    },
  },
  // intro_page
  {
    'yspnfehw': {
      'en': 'Finish',
      'ar': '',
      'es': '',
    },
    '29eyxxy8': {
      'en': 'Home',
      'ar': '',
      'es': '',
    },
  },
  // welcome_page
  {
    'ddvcvdtl': {
      'en': 'SIGN IN',
      'ar': 'تسجيل الدخول',
      'es': 'INICIAR SESIÓN',
    },
    'w845781l': {
      'en': 'SIGN UP',
      'ar': '',
      'es': '',
    },
    'mv9vs9bs': {
      'en': 'Home',
      'ar': '',
      'es': '',
    },
  },
  // mobileNumberlogin_Page
  {
    'uvq08p9i': {
      'en': 'Login to\nYour Account',
      'ar': '',
      'es': '',
    },
    'o9yq2pcp': {
      'en': 'Mobile number',
      'ar': '',
      'es': '',
    },
    'xrn9o5zn': {
      'en': 'Send OTP',
      'ar': '',
      'es': '',
    },
    '3zgavb3j': {
      'en': 'Login',
      'ar': '',
      'es': '',
    },
    'ni9ejfr1': {
      'en': 'Home',
      'ar': '',
      'es': '',
    },
  },
  // verificationcode_page
  {
    'mogiroi8': {
      'en': 'Page Title',
      'ar': '',
      'es': '',
    },
    'bpb13yc6': {
      'en': 'Home',
      'ar': '',
      'es': '',
    },
  },
  // VehicalDetal
  {
    'k8jbvpcb': {
      'en': '\$',
      'ar': '\$',
      'es': 'ps',
    },
    '7d6tgj68': {
      'en': '/',
      'ar': '/',
      'es': '/',
    },
    '3t5g5b9u': {
      'en': 'Details',
      'ar': 'تفاصيل',
      'es': 'Detalles',
    },
  },
  // alertControllerPage
  {
    't7dwge9a': {
      'en': 'Logout',
      'ar': 'تسجيل خروج',
      'es': 'Cerrar sesión',
    },
    'zv41jkt0': {
      'en': 'Are you sure you want to logout  this account',
      'ar': 'هل أنت متأكد أنك تريد تسجيل الخروج من هذا الحساب',
      'es': '¿Estás seguro de que deseas cerrar sesión en esta cuenta?',
    },
    '4zyq3u6i': {
      'en': 'Cancel',
      'ar': 'يلغي',
      'es': 'Cancelar',
    },
    'g1my771c': {
      'en': 'Okay',
      'ar': 'تمام',
      'es': 'Bueno',
    },
  },
  // Information_column
  {
    'mecqc17c': {
      'en': 'Jhon Doe ',
      'ar': 'جون دو',
      'es': 'Jhon Doe',
    },
    '2a6y7poe': {
      'en': 'Delhi',
      'ar': 'دلهي',
      'es': 'Delhi',
    },
    'irbec3jt': {
      'en': '34 Mahaweer Nagarf \nDelhi',
      'ar': '34 مهاوير نجارف\nدلهي',
      'es': '34 Mahaweer Nagarf\nDelhi',
    },
    'y2mykieu': {
      'en': '6 KM',
      'ar': '6 كم',
      'es': '6 KM',
    },
    'uaxt9bdk': {
      'en': 'Online',
      'ar': 'متصل',
      'es': 'En línea',
    },
    '52sp976p': {
      'en': '(2345)',
      'ar': '(2345)',
      'es': '(2345)',
    },
  },
  // receiver_message_page
  {
    '3nqfndpf': {
      'en':
          'I have a lot of work in the house that needs maintenance fsdkfhsdkajfsd       hl;kjshfjhkl;fjhk sjfshlksh js;hfj;ldkhdfjskhl;slkh sfdlkhsdflkh;sdfklfds hkshk j hdjlsk h;lkhjsklh sl jkl hjl hfsdlkljkhf l fdljk.  l ',
      'ar':
          'لدي أعمال كثيرة في المنزل تحتاج إلى صيانة fsdkfhsdkajfsd hl;kjshfjhkl;fjhk sjfshlksh js;hfj;ldkhdfjskhl;slkh sfdlkhsdflkh;sdfklfds hkshk j hdjlsk h;lkhjsklh sl jkl hjl hfsdlkljkhf l fdl jk. ل',
      'es':
          'Tengo mucho trabajo en la casa que necesita mantenimiento fsdkfhsdkajfsd hl;kjshfjhkl;fjhk sjfshlksh js;hfj;ldkhdfjskhl;slkh sfdlkhsdflkh;sdfklfds hkshk j hdjlsk h;lkhjsklh sl jkl hjl hfsdlkljkhf l f dljk. yo',
    },
  },
  // sender_message_page
  {
    'j29afkuc': {
      'en':
          'I have a lot of work in the house that needs maintenance fsdkfhsdkajfsd hgsdjkghdkljghsdkdljgh dldjks gdghkjdfh dkdjlsgh lghdslkdslfdgkdsglkdjhs lh gkldj hdsklg hdsdkgjl hdskjhfshkgjh sglhkdjsghdg',
      'ar':
          'لدي أعمال كثيرة في المنزل تحتاج إلى صيانة fsdkfhsdkajfsd hgsdjkghdkljghsdkdljgh dldjks gdghkjdfh dkdjlsgh lghdslkdslfdgkdsglkdjhs lh gkldj hdsklg hdsdkgjl hdskjhfshkgjh sglhkdjsghdg',
      'es':
          'Tengo mucho trabajo en la casa que necesita mantenimiento fsdkfhsdkajfsd hgsdjkghdkljghsdkdljgh dldjks gdghkjdfh dkdjlsgh lghdslkdslfdgkdsglkdjhs lh gkldj hdsklg hdsdkgjl hdskjhfshkgjh sglhkdjsghdg',
    },
  },
  // send_message
  {
    'd2uzlc4y': {
      'en': 'Type message',
      'ar': 'اكتب الرسالة',
      'es': 'Escribe mensaje',
    },
  },
  // alertCancelPage
  {
    'n968vjav': {
      'en': 'Notice',
      'ar': 'يلاحظ',
      'es': 'Aviso',
    },
    'yqlhvd8z': {
      'en': 'Are you sure you want to cancel  this booking',
      'ar': 'هل أنت متأكد أنك تريد إلغاء هذا الحجز',
      'es': '¿Estás seguro de que quieres cancelar esta reserva?',
    },
    'dpummdq7': {
      'en': 'Cancel',
      'ar': 'يلغي',
      'es': 'Cancelar',
    },
    '8qfzm4fr': {
      'en': 'Okay',
      'ar': 'تمام',
      'es': 'Bueno',
    },
  },
  // alertControllerBackPage
  {
    'lk4gv59a': {
      'en': 'Notice',
      'ar': 'يلاحظ',
      'es': 'Aviso',
    },
    'glrp0tgn': {
      'en': 'Okay',
      'ar': 'تمام',
      'es': 'Bueno',
    },
  },
  // alertAccountDelete
  {
    'j8l4d67u': {
      'en': 'Delete My Account',
      'ar': 'احذف حسابي',
      'es': 'borrar mi cuenta',
    },
    'fwge82n8': {
      'en': 'Are you sure do you want to permanently delete your account ?',
      'ar': 'هل أنت متأكد أنك تريد ذلك حذف حسابك نهائيا؟',
      'es': '¿Estás seguro de que quieres ¿Eliminar permanentemente tu cuenta?',
    },
    'cuuxlwr3': {
      'en': 'Cancel',
      'ar': 'يلغي',
      'es': 'Cancelar',
    },
    '01fon2ld': {
      'en': 'Okay',
      'ar': 'تمام',
      'es': 'Bueno',
    },
  },
  // RatingViewPage
  {
    'wdgzac1m': {
      'en': 'Please Share your Rating',
      'ar': 'يرجى مشاركة تقييمك',
      'es': 'Por favor comparte tu calificación',
    },
    'u0764vh7': {
      'en': 'Submit',
      'ar': 'يُقدِّم',
      'es': 'Entregar',
    },
  },
  // Mode_screen
  {
    'qbiecm3r': {
      'en': 'Light Mode',
      'ar': '',
      'es': '',
    },
    's39meop0': {
      'en': 'Dark Mode',
      'ar': '',
      'es': '',
    },
  },
  // Miscellaneous
  {
    'vsrx4w4a': {
      'en':
          'In order to take a picture or video, this app requires permission to access the camera.',
      'ar':
          'لالتقاط صورة أو مقطع فيديو، يتطلب هذا التطبيق إذنًا للوصول إلى الكاميرا.',
      'es':
          'Para tomar una foto o grabar un video, esta aplicación requiere permiso para acceder a la cámara.',
    },
    '0idnvf4q': {
      'en':
          'In order to upload data, this app requires permission to access the photo library.',
      'ar':
          'من أجل تحميل البيانات، يتطلب هذا التطبيق إذنًا للوصول إلى مكتبة الصور.',
      'es':
          'Para cargar datos, esta aplicación requiere permiso para acceder a la biblioteca de fotos.',
    },
    'yvtoshqx': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '0guyzszu': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'quwk9rko': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '4ta0yx4j': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '252wmib8': {
      'en': '',
      'ar': '',
      'es': '',
    },
    's3lgufym': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'x3ql454q': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '7t82j6u5': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'k1eesspb': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'i7wrquzv': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'e8i89wgq': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'li9jtfbf': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'pxowvbgg': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'g8u718la': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'ujcpo7aq': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'ajnyijdi': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '9c71o3tg': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'wi34mmmt': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'giagrldv': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'ljph6mrv': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'd3kypjks': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'oo8tt1tw': {
      'en': '',
      'ar': '',
      'es': '',
    },
    'mvgawvx0': {
      'en': '',
      'ar': '',
      'es': '',
    },
    '6bdthdpo': {
      'en': '',
      'ar': '',
      'es': '',
    },
  },
].reduce((a, b) => a..addAll(b));
