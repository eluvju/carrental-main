import 'dart:convert';
import 'dart:math' show cos, sqrt, asin;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui' as ui;
import 'constant.dart';
import 'flutter/flutter_icon_button.dart';
import 'flutter/flutter_theme.dart';
import 'flutter/internationalization.dart';



class YourMapWidget extends StatefulWidget {
  dynamic pick_lat;
  dynamic pick_long;
  dynamic drop_lat;
  dynamic drop_long;


  YourMapWidget(
      {
        required this.pick_lat,
        required this.pick_long,
        required this.drop_lat,
        required this.drop_long,

      });
  @override
  _YourMapWidgetState createState() => _YourMapWidgetState();
}

class _YourMapWidgetState extends State<YourMapWidget> {
  GoogleMapController? _mapController;
  List<LatLng> _routeCoordinates = [];
  LatLng _pickupLocation = LatLng(22.7196, 75.8577); // Default pickup location
  LatLng _dropoffLocation = LatLng(22.9676, 76.0534);
  Uint8List? _pickupMarkerIcon;
  Uint8List? _dropoffMarkerIcon;
  // Default drop-off location
  bool _hasData = true;
  bool _isVisible = false;
  double? distance;
  String? time;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print('=======widget.pick_lat========${widget.pick_lat}');
    print('=======widget.pick_long========${widget.pick_long}');
    print('=======widget.drop_lat========${widget.drop_lat}');
    print('=======widget.drop_long========${widget.drop_long}');
    drawRoute(widget.pick_lat,widget.pick_long, widget.drop_lat, widget.drop_long);
    double haversineDistance =
    calculateDistance(widget.pick_lat, widget.pick_long, widget.drop_lat, widget.drop_long);
    print('Haversine distance between pickup and drop-off: $haversineDistance km');

    // Calculate distance using Google Maps Distance Matrix API
    getDistance(widget.pick_lat, widget.pick_long, widget.drop_lat, widget.drop_long)
        .then((value) {
      setState(() {
        distance = value['distance'];
        time = value['time'];
        print("Distance: $distance, Time: $time");
      });
    }).catchError((error) {
      print('Error: $error');
    });

  }

  Future<void> _loadMarkerIcons() async {
    print("========loadicon=====${_loadMarkerIcons()}");
    _pickupMarkerIcon = await _getMarkerIcon('assets/images/circle.png');
    _dropoffMarkerIcon = await _getMarkerIcon('assets/images/circle.png');
  }

  Future<Uint8List> _getMarkerIcon(String assetPath) async {
    ByteData data = await rootBundle.load(assetPath);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }


  @override
  Widget build(BuildContext context) {
    // double distance = calculateDistance(widget.pick_lat, widget.pick_long, widget.drop_lat, widget.drop_long);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: FlutterTheme.of(context).secondaryBackground,
        automaticallyImplyLeading: false,
        leading: InkWell(
          onTap: () {
            Helper.popScreen(context);
          },
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0,top: 15,right: 0,bottom: 10),
            child: Image.asset('assets/images/back_icon_with_bg.png',height: 30,width: 30,),
          ),
        ),
        title: Text("Route Screen",
          // FFLocalizations.of(context).getText(
          //   'p6r3ar1p' /* More Filter */,
          // ),
          style: FlutterTheme.of(context).headlineMedium.override(
              fontFamily: 'Urbanist',
              color: FlutterTheme.of(context).primaryText,
              fontSize: 18.0,fontWeight: FontWeight.w600
          ),
        ),
        actions: [],
        centerTitle: false,
        // elevation: 2.0,
      ),

      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            child: GoogleMap(
              onMapCreated: (controller) {
                _mapController = controller;
                // zoomOutPolyline();
              },
              markers: {
                Marker(
                  onTap: () {
                  },
                  markerId: MarkerId('pickup'),
                  position: LatLng(widget.pick_lat, widget.pick_long),
                  icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
                  // infoWindow: InfoWindow(title: widget.pickup_address),
                ),
                Marker(
                  onTap: () {
                  },
                  markerId: MarkerId('dropoff'),
                  position: LatLng(widget.drop_lat, widget.drop_long),
                  icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
                  // infoWindow: InfoWindow(title: widget.drop_address),
                ),
              },
              polylines: {
                Polyline(
                  polylineId: PolylineId('route'),
                  color: Colors.blue,
                  points: _routeCoordinates,
                  width: 4,
                ),
              },
              initialCameraPosition: CameraPosition(
                target: LatLng(widget.pick_lat, widget.pick_long),
                zoom: 5,
              ),
            ),
          ),
          // _deliveryDeliveries == null
          //     ? _hasData
          //     ? Container()
          //     : Container(
          //   child: Center(
          //     child: Text("NO DATA"),
          //   ),
          // ):
          // Align(
          //   alignment: AlignmentDirectional(-1.0, 1.0),
          //   child: Container(
          //     width: double.infinity,
          //     height: 300.0,
          //     decoration: BoxDecoration(
          //       color:Colors.white,
          //       borderRadius: BorderRadius.only(
          //         bottomLeft: Radius.circular(0.0),
          //         bottomRight: Radius.circular(0.0),
          //         topLeft: Radius.circular(30.0),
          //         topRight: Radius.circular(30.0),
          //       ),
          //     ),
          //     child: Padding(
          //       padding: EdgeInsetsDirectional.fromSTEB(10.0, 5.0, 10.0, 0.0),
          //       child: Column(
          //           mainAxisSize: MainAxisSize.max,
          //           // crossAxisAlignment: CrossAxisAlignment.start,
          //           children: [
          //             Padding(
          //               padding: EdgeInsetsDirectional.fromSTEB(
          //                   0.0, 20.0, 0.0, 0.0),
          //               child: Row(
          //                 mainAxisSize: MainAxisSize.max,
          //                 crossAxisAlignment: CrossAxisAlignment.start,
          //                 children: [
          //                   Align(
          //                     alignment: AlignmentDirectional(0.0, -1.0),
          //                     child: ClipRRect(
          //                       borderRadius: BorderRadius.circular(8.0),
          //                       child: Image.asset(
          //                         'assets/images/Frame_65_(1).png',
          //                         width: 20.0,
          //                         height: 128.0,
          //                         fit: BoxFit.cover,
          //                       ),
          //                     ),
          //                   ),
          //                   Padding(
          //                     padding: EdgeInsetsDirectional.fromSTEB(
          //                         10.0, 0.0, 0.0, 0.0),
          //                     child: Column(
          //                       mainAxisSize: MainAxisSize.max,
          //                       children: [
          //                         Column(
          //                           mainAxisSize: MainAxisSize.max,
          //                           crossAxisAlignment:
          //                           CrossAxisAlignment.start,
          //                           children: [
          //                             Row(
          //                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //                               children: [
          //                                 Text(
          //                                   FFLocalizations.of(context).getText(
          //                                     'kko8h2vn' /* Pickup Location */,
          //                                   ),
          //                                   style: FlutterTheme.of(context)
          //                                       .bodyMedium
          //                                       .override(
          //                                     fontFamily: 'Poppins',
          //                                     color: Color(0xFFF11616),
          //                                     fontSize: 15.0,
          //                                     fontWeight: FontWeight.w500,
          //                                   ),
          //                                 ),
          //
          //                               ],
          //                             ),
          //
          //                             Container(
          //                               width: 210,
          //                               child: Text(
          //                                widget.pickup_address,
          //                                 style: FlutterTheme.of(context)
          //                                     .bodyMedium
          //                                     .override(
          //                                   fontFamily: 'Poppins',
          //                                   fontSize: 12.0,
          //                                   fontWeight: FontWeight.w300,
          //                                 ),
          //                               ),
          //                             ),
          //                           ],
          //                         ),
          //                         Padding(
          //                           padding: EdgeInsetsDirectional.fromSTEB(
          //                               0.0, 28.0, 0.0, 0.0),
          //                           child: Column(
          //                             mainAxisSize: MainAxisSize.max,
          //                             crossAxisAlignment:
          //                             CrossAxisAlignment.start,
          //                             children: [
          //                               Text(
          //                                 FFLocalizations.of(context).getText(
          //                                   'zr022zwo' /* Drop-Off Location */,
          //                                 ),
          //                                 style: FlutterTheme.of(context)
          //                                     .bodyMedium
          //                                     .override(
          //                                   fontFamily: 'Poppins',
          //                                   color: Color(0xFF099AF6),
          //                                   fontSize: 15.0,
          //                                   fontWeight: FontWeight.w500,
          //                                 ),
          //                               ),
          //                               Container(
          //                                 width: 210,
          //                                 child: Text(
          //                                   // FFLocalizations.of(context).getText(
          //                                   //   '5hs4rqpf' /* 73, rave street, 110-7  near f... */,
          //                                   // ),
          //                                 widget.drop_address,
          //                                   style: FlutterTheme.of(context)
          //                                       .bodyMedium
          //                                       .override(
          //                                     fontFamily: 'Poppins',
          //                                     fontSize: 12.0,
          //                                     fontWeight: FontWeight.w300,
          //                                   ),
          //                                 ),
          //                               ),
          //                               SizedBox(
          //                                 height: 20,
          //                               ),
          //
          //                             ],
          //                           ),
          //                         ),
          //
          //                       ],
          //                     ),
          //                   ),
          //                 ],
          //               ),
          //             ),
          //             SizedBox(
          //               height: 20,
          //             ),
          //             // Center(
          //             //   child: InkWell(
          //             //     onTap: (){
          //             //       widget.whichscreen=="2"?
          //             //       Navigator.pushAndRemoveUntil(
          //             //           context, MaterialPageRoute(builder: (context) => CurrentDeliveryDetailsWidget(
          //             //
          //             //         currentOrderId : widget.order_id, driverdeliverycost: widget.driverdeliverycost,
          //             //         // driverdeliverycost: driverdeliverycost,
          //             //
          //             //       )), (
          //             //           route) => true):
          //             //       Navigator.pushAndRemoveUntil(
          //             //           context, MaterialPageRoute(builder: (context) => DeliveryDetailsWidget(
          //             //
          //             //         orderId : widget.order_id ,
          //             //
          //             //       )), (
          //             //           route) => true);
          //             //     },
          //             //     child: Center(
          //             //       child: Container(
          //             //         decoration: BoxDecoration(
          //             //             color: Color(0xFF2451DC),
          //             //           borderRadius: BorderRadius.circular(20)
          //             //         ),
          //             //         padding: EdgeInsets.symmetric(horizontal: 60,vertical: 10),
          //             //
          //             //         child: Text(
          //             //           // FFLocalizations.of(context).getText(
          //             //           //   'zw7j3hjk' /* 26, Local Street,  */,
          //             //           // ),
          //             //           "Show Detail",
          //             //           style: FlutterTheme.of(context)
          //             //               .bodyMedium
          //             //               .override(
          //             //               fontFamily: 'Poppins',
          //             //               fontSize: 16.0,
          //             //               fontWeight: FontWeight.w500,color: Colors.white
          //             //           ),
          //             //         ),
          //             //       ),
          //             //     ),
          //             //   ),
          //             // )
          //             // Row(
          //             //   mainAxisSize: MainAxisSize.max,
          //             //   crossAxisAlignment: CrossAxisAlignment.start,
          //             //   children: [
          //             //     Container(
          //             //
          //             //       decoration: BoxDecoration(),
          //             //       child: Text(
          //             //         FFLocalizations.of(context).getText(
          //             //           'fs13eeez' /* Pick Address */,
          //             //         ),
          //             //         style: FlutterFlowTheme.of(context)
          //             //             .bodyMedium
          //             //             .override(
          //             //           fontFamily: 'Poppins',
          //             //           fontSize: 14.0,
          //             //           fontWeight: FontWeight.w600,
          //             //         ),
          //             //       ),
          //             //     ),
          //             //     Text(
          //             //      " :-",
          //             //       style: FlutterFlowTheme.of(context)
          //             //           .bodyMedium
          //             //           .override(
          //             //         fontFamily: 'Poppins',
          //             //         fontSize: 12.0,
          //             //         fontWeight: FontWeight.w500,
          //             //       ),
          //             //     ),
          //             //
          //             //   ]
          //             // ),
          //             // Text(
          //             //   // FFLocalizations.of(context).getText(
          //             //   //   'zw7j3hjk' /* 26, Local Street,  */,
          //             //   // ),
          //             //   widget.pickup_address,
          //             //   style: FlutterFlowTheme.of(context)
          //             //       .bodyMedium
          //             //       .override(
          //             //     fontFamily: 'Poppins',
          //             //     fontSize: 12.0,
          //             //     fontWeight: FontWeight.w500,
          //             //   ),
          //             // ),
          //             // SizedBox(
          //             //   height: 20,
          //             // ),
          //             // Row(
          //             //     mainAxisSize: MainAxisSize.max,
          //             //     crossAxisAlignment: CrossAxisAlignment.start,
          //             //     children: [
          //             //       Container(
          //             //
          //             //         decoration: BoxDecoration(),
          //             //         child: Text(
          //             //           FFLocalizations.of(context).getText(
          //             //             '9wzrmj20' /* Pick Address */,
          //             //           ),
          //             //           style: FlutterFlowTheme.of(context)
          //             //               .bodyMedium
          //             //               .override(
          //             //             fontFamily: 'Poppins',
          //             //             fontSize: 14.0,
          //             //             fontWeight: FontWeight.w600,
          //             //           ),
          //             //         ),
          //             //       ),
          //             //       Text(
          //             //         " :-",
          //             //         style: FlutterFlowTheme.of(context)
          //             //             .bodyMedium
          //             //             .override(
          //             //           fontFamily: 'Poppins',
          //             //           fontSize: 12.0,
          //             //           fontWeight: FontWeight.w500,
          //             //         ),
          //             //       ),
          //             //
          //             //     ]
          //             // ),
          //             // Text(
          //             //   // FFLocalizations.of(context).getText(
          //             //   //   'zw7j3hjk' /* 26, Local Street,  */,
          //             //   // ),
          //             //   widget.drop_address,
          //             //   style: FlutterFlowTheme.of(context)
          //             //       .bodyMedium
          //             //       .override(
          //             //     fontFamily: 'Poppins',
          //             //     fontSize: 12.0,
          //             //     fontWeight: FontWeight.w500,
          //             //   ),
          //             // ),
          //             // SizedBox(
          //             //   height: 50,
          //             // ),
          //             // InkWell(
          //             //   onTap: (){
          //             //     Navigator.pushAndRemoveUntil(
          //             //         context, MaterialPageRoute(builder: (context) => DeliveryDetailsWidget(
          //             //
          //             //       orderId : widget.order_id ,
          //             //
          //             //     )), (
          //             //         route) => true);
          //             //   },
          //             //   child: Center(
          //             //     child: Container(
          //             //       padding: EdgeInsets.symmetric(horizontal: 40,vertical: 10),
          //             //       color: Color(0xFF2451DC),
          //             //       child: Text(
          //             //         // FFLocalizations.of(context).getText(
          //             //         //   'zw7j3hjk' /* 26, Local Street,  */,
          //             //         // ),
          //             //         "Show Detail",
          //             //         style: FlutterFlowTheme.of(context)
          //             //             .bodyMedium
          //             //             .override(
          //             //           fontFamily: 'Poppins',
          //             //           fontSize: 12.0,
          //             //           fontWeight: FontWeight.w500,color: Colors.white
          //             //         ),
          //             //       ),
          //             //     ),
          //             //   ),
          //             // )
          //
          //             // Text(
          //             //   'Available Gig',
          //             //   textAlign: TextAlign.center,
          //             //   style: FlutterFlowTheme.of(context).bodyMedium.override(
          //             //     fontFamily: 'Montserrat',
          //             //     color:Colors.blue,
          //             //     fontSize: 22.0,
          //             //     fontWeight: FontWeight.bold,
          //             //     useGoogleFonts: GoogleFonts.asMap().containsKey(
          //             //         FlutterFlowTheme.of(context).bodyMediumFamily),
          //             //   ),
          //             // ),
          //             // // Text(
          //             // //   distance.toString(),
          //             // //   textAlign: TextAlign.center,
          //             // //   style: FlutterFlowTheme.of(context).bodyMedium.override(
          //             // //     fontFamily: 'Montserrat',
          //             // //     color: FlutterFlowTheme.of(context).btnNaviBlue,
          //             // //     fontSize: 10.0,
          //             // //     fontWeight: FontWeight.bold,
          //             // //     useGoogleFonts: GoogleFonts.asMap().containsKey(
          //             // //         FlutterFlowTheme.of(context).bodyMediumFamily),
          //             // //   ),
          //             // // ),
          //             // Divider(
          //             //   thickness: 1.0,
          //             //   color:Colors.grey
          //             // ),
          //             // Padding(
          //             //   padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
          //             //   child: Row(
          //             //       mainAxisSize: MainAxisSize.max,
          //             //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //             //       crossAxisAlignment: CrossAxisAlignment.start,
          //             //       children: [
          //             //         Expanded(
          //             //           child: Row(
          //             //               mainAxisSize: MainAxisSize.max,
          //             //               children: [
          //             //                 Column(
          //             //                   mainAxisSize: MainAxisSize.max,
          //             //                   crossAxisAlignment: CrossAxisAlignment.center,
          //             //                   children: [
          //             //                     Container(
          //             //                       width: 6.0,
          //             //                       height: 6.0,
          //             //                       decoration: BoxDecoration(
          //             //                         color:
          //             //                         Colors.black,
          //             //                         shape: BoxShape.circle,
          //             //                       ),
          //             //                     ),
          //             //                     Container(
          //             //                       width: 1.0,
          //             //                       height: 17.0,
          //             //                       decoration: BoxDecoration(
          //             //                         color:
          //             //                         Colors.blue,
          //             //                       ),
          //             //                     ),
          //             //                     Container(
          //             //                       width: 6.0,
          //             //                       height: 6.0,
          //             //                       decoration: BoxDecoration(
          //             //                         color:
          //             //                        Colors.blue,
          //             //                         shape: BoxShape.circle,
          //             //                       ),
          //             //                     ),
          //             //                   ],
          //             //                 ),
          //             //                 Expanded(
          //             //                   child: Column(
          //             //                     mainAxisSize: MainAxisSize.max,
          //             //                     crossAxisAlignment: CrossAxisAlignment.start,
          //             //                     children: [
          //             //                       Text(
          //             //                         widget.pickup_address,
          //             //                         textAlign: TextAlign.start,
          //             //                         overflow: TextOverflow.ellipsis,
          //             //                         style: FlutterFlowTheme.of(context)
          //             //                             .bodyMedium
          //             //                             .override(
          //             //                           fontFamily:
          //             //                           FlutterFlowTheme.of(context)
          //             //                               .bodyMediumFamily,
          //             //                           color:Colors.blue,
          //             //                           fontSize: 14.0,
          //             //                           fontWeight: FontWeight.normal,
          //             //                           useGoogleFonts: GoogleFonts.asMap()
          //             //                               .containsKey(
          //             //                               FlutterFlowTheme.of(context)
          //             //                                   .bodyMediumFamily),
          //             //                         ),
          //             //                       ),
          //             //                       Text(
          //             //                         widget.drop_address,
          //             //                         textAlign: TextAlign.start,
          //             //                         overflow: TextOverflow.ellipsis,
          //             //                         style: FlutterFlowTheme.of(context)
          //             //                             .bodyMedium
          //             //                             .override(
          //             //                           fontFamily:
          //             //                           FlutterFlowTheme.of(context)
          //             //                               .bodyMediumFamily,
          //             //                           color:Colors.blue,
          //             //                           fontSize: 14.0,
          //             //                           fontWeight: FontWeight.normal,
          //             //                           useGoogleFonts: GoogleFonts.asMap()
          //             //                               .containsKey(
          //             //                               FlutterFlowTheme.of(context)
          //             //                                   .bodyMediumFamily),
          //             //                         ),
          //             //                       ),
          //             //                     ],
          //             //                   ),
          //             //                 ),
          //             //               ]
          //             //             // .divide(SizedBox(width: 12.0)),
          //             //           ),
          //             //         ),
          //             //         Row(
          //             //           mainAxisSize: MainAxisSize.max,
          //             //           crossAxisAlignment: CrossAxisAlignment.start,
          //             //           children: [
          //             //             Text(
          //             //               '\$',
          //             //               style: FlutterFlowTheme.of(context)
          //             //                   .bodyMedium
          //             //                   .override(
          //             //                 fontFamily: FlutterFlowTheme.of(context)
          //             //                     .bodyMediumFamily,
          //             //                 fontSize: 20.0,
          //             //                 fontWeight: FontWeight.bold,
          //             //                 useGoogleFonts: GoogleFonts.asMap()
          //             //                     .containsKey(FlutterFlowTheme.of(context)
          //             //                     .bodyMediumFamily),
          //             //               ),
          //             //             ),
          //             //             Text(
          //             //               widget.price,
          //             //               style: FlutterFlowTheme.of(context)
          //             //                   .bodyMedium
          //             //                   .override(
          //             //                 fontFamily: FlutterFlowTheme.of(context)
          //             //                     .bodyMediumFamily,
          //             //                 fontSize: 45.0,
          //             //                 fontWeight: FontWeight.bold,
          //             //                 useGoogleFonts: GoogleFonts.asMap()
          //             //                     .containsKey(FlutterFlowTheme.of(context)
          //             //                     .bodyMediumFamily),
          //             //               ),
          //             //             ),
          //             //             Text(
          //             //               widget.price_decimal,
          //             //               style: FlutterFlowTheme.of(context)
          //             //                   .bodyMedium
          //             //                   .override(
          //             //                 fontFamily: FlutterFlowTheme.of(context)
          //             //                     .bodyMediumFamily,
          //             //                 fontSize: 20.0,
          //             //                 fontWeight: FontWeight.bold,
          //             //                 useGoogleFonts: GoogleFonts.asMap()
          //             //                     .containsKey(FlutterFlowTheme.of(context)
          //             //                     .bodyMediumFamily),
          //             //               ),
          //             //             ),
          //             //           ],
          //             //         ),
          //             //       ]
          //             //     // .divide(SizedBox(width: 10.0)),
          //             //
          //             //   ),
          //             // ),
          //             // FFButtonWidget(
          //             //   onPressed: () async {
          //             //     await showModalBottomSheet(
          //             //       isScrollControlled: true,
          //             //       backgroundColor: Colors.transparent,
          //             //       enableDrag: false,
          //             //       context: context,
          //             //       builder: (context) {
          //             //         return Padding(
          //             //           padding: MediaQuery.viewInsetsOf(context),
          //             //           child: Container(
          //             //             height: double.infinity,
          //             //             child:Container(
          //             //               color: Colors.grey,
          //             //             ),
          //             //             // OrderFullDetailPopComponentWidget(
          //             //             //   size: widget.size,
          //             //             //   catergory: widget.catergory, quantity: widget.quantity,
          //             //             //   vehicle_type: widget.vehicle_type, name: widget.name, sender_number: widget.sender_number,
          //             //             //   email: widget.email, order_number: widget.order_number, notes: widget.notes,
          //             //             //   pickup_address:widget.pickup_address, drop_address: widget.drop_address,
          //             //             //   pick_lat: widget.pick_lat, pick_long: widget.pick_long, drop_lat: widget.drop_lat,
          //             //             //   drop_long: widget.drop_long, receiver_name: widget.receiver_name,
          //             //             //   receiver_number: widget.receiver_number, receiver_email: widget.receiver_email,
          //             //             //   receiver_notes: widget.receiver_notes, weight: widget.weight, price: widget.price,
          //             //             //   price_decimal: widget.price_decimal, distance:distance.toString(), time: time.toString(),
          //             //             // ),
          //             //           ),
          //             //         );
          //             //       },
          //             //     );
          //             //     // .then((value) =>
          //             //     // safeSetState(() {}));
          //             //   },
          //             //   text: 'Show Details',
          //             //   options: FFButtonOptions(
          //             //     width: double.infinity,
          //             //     padding:
          //             //     EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
          //             //     iconPadding:
          //             //     EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
          //             //     color:Colors.white,
          //             //     textStyle: FlutterFlowTheme.of(context).titleSmall.override(
          //             //       fontFamily: 'Montserrat',
          //             //       color: Colors.blue,
          //             //       fontWeight: FontWeight.bold,
          //             //       useGoogleFonts: GoogleFonts.asMap().containsKey(
          //             //           FlutterFlowTheme.of(context).titleSmallFamily),
          //             //     ),
          //             //     elevation: 0.0,
          //             //     borderSide: BorderSide(
          //             //       color: Colors.transparent,
          //             //       width: 1.0,
          //             //     ),
          //             //     borderRadius: BorderRadius.circular(24.0),
          //             //   ),
          //             // ),
          //             //
          //             //
          //             // Padding(
          //             //   padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
          //             //   child: FFButtonWidget(
          //             //     onPressed: () async  {
          //             //       _deliveryDeliveries!.deliverydata!.deliveryStatus.toString()=="Delivered"?
          //             //       await showModalBottomSheet(
          //             //         isScrollControlled: true,
          //             //         backgroundColor: Colors.transparent,
          //             //         enableDrag: false,
          //             //         context: context,
          //             //         builder: (context) {
          //             //           return Padding(
          //             //             padding: MediaQuery.viewInsetsOf(context),
          //             //             child: Container(
          //             //               height: double.infinity,
          //             //               child: Container(
          //             //                 color: Colors.blue,
          //             //               )
          //             //               // OrderSubmittedComponentWidget(size: widget.size,
          //             //               //   catergory: widget.catergory, quantity: widget.quantity,
          //             //               //   vehicle_type: widget.vehicle_type, name: widget.name, sender_number: widget.sender_number,
          //             //               //   email: widget.email, order_number: widget.order_number, notes: widget.notes,
          //             //               //   pickup_address:widget.pickup_address, drop_address: widget.drop_address,
          //             //               //   pick_lat: widget.pick_lat, pick_long: widget.pick_long, drop_lat: widget.drop_lat,
          //             //               //   drop_long: widget.drop_long, receiver_name: widget.receiver_name,
          //             //               //   receiver_number: widget.receiver_number, receiver_email: widget.receiver_email,
          //             //               //   receiver_notes: widget.receiver_notes, weight: widget.weight, price: widget.price,
          //             //               //   price_decimal: widget.price_decimal,),
          //             //             ),
          //             //           );
          //             //         },
          //             //       ):
          //             //       // .then((value) => safeSetState(() {})):
          //             //       showAlertDialog( context,widget.order_id,widget.price+widget.price_decimal);
          //             //       // await showModalBottomSheet(
          //             //       //   isScrollControlled: true,
          //             //       //   backgroundColor: Colors.transparent,
          //             //       //   enableDrag: false,
          //             //       //   context: context,
          //             //       //   builder: (context) {
          //             //       //     return Padding(
          //             //       //       padding: MediaQuery.viewInsetsOf(context),
          //             //       //       child: Container(
          //             //       //         height: double.infinity,
          //             //       //         child: OrderSubmittedComponentWidget(size: widget.size,
          //             //       //           catergory: widget.catergory, quantity: widget.quantity,
          //             //       //           vehicle_type: widget.vehicle_type, name: widget.name, sender_number: widget.sender_number,
          //             //       //           email: widget.email, order_number: widget.order_number, notes: widget.notes,
          //             //       //           pickup_address:widget.pickup_address, drop_address: widget.drop_address,
          //             //       //           pick_lat: widget.pick_lat, pick_long: widget.pick_long, drop_lat: widget.drop_lat,
          //             //       //           drop_long: widget.drop_long, receiver_name: widget.receiver_name,
          //             //       //           receiver_number: widget.receiver_number, receiver_email: widget.receiver_email,
          //             //       //           receiver_notes: widget.receiver_notes, weight: widget.weight, price: widget.price,
          //             //       //           price_decimal: widget.price_decimal,),
          //             //       //       ),
          //             //       //     );
          //             //       //   },
          //             //       // ).then((value) => safeSetState(() {}));
          //             //     },
          //             //
          //             //     text:   (_deliveryDeliveries?.deliverydata?.deliveryStatus?.toString() == "Open")
          //             //         ? "Accept Order"
          //             //         : (_deliveryDeliveries?.deliverydata?.deliveryStatus?.toString() == "Accepted")
          //             //         ? "Pick up Order"
          //             //         : (_deliveryDeliveries?.deliverydata?.deliveryStatus?.toString() == "PickedUp")
          //             //         ? "Deliver Order"
          //             //         : "Order Completed",
          //             //     // text: _deliveryDetailModel!.deliverydata!.deliveryStatus.toString(),
          //             //     options: FFButtonOptions(
          //             //       width: double.infinity,
          //             //       height: 50.0,
          //             //       padding:
          //             //       EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
          //             //       iconPadding:
          //             //       EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
          //             //       color:Colors.blue,
          //             //       textStyle: FlutterFlowTheme.of(context)
          //             //           .titleSmall
          //             //           .override(
          //             //         fontFamily: 'Montserrat',
          //             //         color: Colors.white,
          //             //         fontWeight: FontWeight.bold,
          //             //         useGoogleFonts: GoogleFonts.asMap().containsKey(
          //             //             FlutterFlowTheme.of(context).titleSmallFamily),
          //             //       ),
          //             //       elevation: 3.0,
          //             //       borderSide: BorderSide(
          //             //         color: Colors.transparent,
          //             //         width: 1.0,
          //             //       ),
          //             //       borderRadius: BorderRadius.circular(24.0),
          //             //     ),
          //             //   ),
          //             // ),
          //             // Padding(
          //             //   padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
          //             //   child: FFButtonWidget(
          //             //     onPressed: () async {
          //             //       Navigator.pop(context);
          //             //     },
          //             //     text: 'Cancel',
          //             //     options: FFButtonOptions(
          //             //       width: double.infinity,
          //             //       padding:
          //             //       EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
          //             //       iconPadding:
          //             //       EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
          //             //       color:Colors.white,
          //             //       textStyle: FlutterFlowTheme.of(context)
          //             //           .titleSmall
          //             //           .override(
          //             //         fontFamily: 'Montserrat',
          //             //         color: Colors.black,
          //             //         fontWeight: FontWeight.bold,
          //             //         useGoogleFonts: GoogleFonts.asMap().containsKey(
          //             //             FlutterFlowTheme.of(context).titleSmallFamily),
          //             //       ),
          //             //       elevation: 0.0,
          //             //       borderSide: BorderSide(
          //             //         color: Colors.transparent,
          //             //         width: 0.0,
          //             //       ),
          //             //       borderRadius: BorderRadius.circular(24.0),
          //             //     ),
          //             //   ),
          //             // ),
          //           ]
          //         // .divide(SizedBox(height: 8.0)),
          //       ),
          //     ),
          //   ),
          // ),
        ],
      ),

      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     drawRoute(widget.pick_lat,widget.pick_long, widget.drop_lat, widget.drop_long);
      //   },
      //   child: Icon(Icons.directions),
      // ),
    );
  }

  Future<Map<String, dynamic>> getDistance(double lat1, double lon1, double lat2, double lon2) async {
    final apiKey = 'AIzaSyDC3tem0TZwtIX1W4RhFiZasKwI2T8g34k'; // Replace with your API key
    final origin = '$lat1,$lon1';
    final destination = '$lat2,$lon2';
    final url = 'https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=$origin&destinations=$destination&key=$apiKey';

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final distanceText = data['rows'][0]['elements'][0]['distance']['text'];
      final timeText = data['rows'][0]['elements'][0]['duration']['text'];
      final distanceValue = double.tryParse(distanceText.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0;
      return {'distance': distanceValue, 'time': timeText};
    } else {
      throw Exception('Failed to fetch distance and time');
    }
  }

  double calculateDistance(lat1, lon1, lat2, lon2) {
    final p = 0.017453292519943295; // Math.PI / 180
    final c = 0.5 - cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(c)); // 2 * R; R = 6371 km
  }












  setProgress(bool show) {
    if (mounted)
      setState(() {
        _isVisible = show;
      });
  }


  void drawRoute(double pickupLatitude, double pickupLongitude, double dropoffLatitude, double dropoffLongitude) async {
    _routeCoordinates.clear(); // Clear previous route

    final origin = '$pickupLatitude,$pickupLongitude';
    final destination = '$dropoffLatitude,$dropoffLongitude';

    final apiKey = 'AIzaSyDC3tem0TZwtIX1W4RhFiZasKwI2T8g34k'; // Replace with your actual Google Maps API key
    final url =
        'https://maps.googleapis.com/maps/api/directions/json?origin=$origin&destination=$destination&mode=driving&key=$apiKey';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final routes = json['routes'];

        if (routes != null && routes.isNotEmpty) {
          final route = routes[0];
          final overviewPolyline = route['overview_polyline'];
          final points = overviewPolyline['points'];

          if (points != null) {
            List<LatLng> decodedRoute = decodePolyline(points);

            setState(() {
              _routeCoordinates = decodedRoute;
            });

            // Fit map bounds to show the entire route
            LatLngBounds bounds = boundsFromLatLngList(decodedRoute);
            _mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 100));
          } else {
            // Handle no points in the polyline
            print("No points in the polyline");
          }
        } else {
          // Handle no route found
          print("No route found");
        }
      } else {
        // Handle error response
        print("Error fetching route: ${response.statusCode}");
      }
    } catch (e) {
      // Handle network or other exceptions
      print("Exception during route fetching: $e");
    }
  }

  void zoomOutPolyline() {
    if (_routeCoordinates.isEmpty || _mapController == null) return;

    double minLat = _routeCoordinates.first.latitude;
    double maxLat = _routeCoordinates.first.latitude;
    double minLng = _routeCoordinates.first.longitude;
    double maxLng = _routeCoordinates.first.longitude;

    // Finding the bounds of the polyline coordinates
    for (LatLng point in _routeCoordinates) {
      if (point.latitude < minLat) minLat = point.latitude;
      if (point.latitude > maxLat) maxLat = point.latitude;
      if (point.longitude < minLng) minLng = point.longitude;
      if (point.longitude > maxLng) maxLng = point.longitude;
    }

    // Creating LatLngBounds
    LatLngBounds bounds = LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );

    // Zooming the camera to fit the bounds
    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(
        bounds,
        50, // padding
      ),
    );
  }
}



List<LatLng> decodePolyline(String encoded) {
  List<LatLng> points = [];
  int index = 0;
  int len = encoded.length;
  int lat = 0, lng = 0;

  while (index < len) {
    int b, shift = 0, result = 0;
    do {
      b = encoded.codeUnitAt(index++) - 63;
      result |= (b & 0x1F) << shift;
      shift += 5;
    } while (b >= 0x20);
    int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
    lat += dlat;

    shift = 0;
    result = 0;
    do {
      b = encoded.codeUnitAt(index++) - 63;
      result |= (b & 0x1F) << shift;
      shift += 5;
    } while (b >= 0x20);
    int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
    lng += dlng;

    points.add(LatLng(lat / 1E5, lng / 1E5));
  }
  return points;
}

LatLngBounds boundsFromLatLngList(List<LatLng> list) {
  double minLat = list.first.latitude;
  double maxLat = list.first.latitude;
  double minLng = list.first.longitude;
  double maxLng = list.first.longitude;

  for (LatLng latLng in list) {
    if (latLng.latitude > maxLat) maxLat = latLng.latitude;
    if (latLng.latitude < minLat) minLat = latLng.latitude;
    if (latLng.longitude > maxLng) maxLng = latLng.longitude;
    if (latLng.longitude < minLng) minLng = latLng.longitude;
  }

  return LatLngBounds(
    southwest: LatLng(minLat, minLng),
    northeast: LatLng(maxLat, maxLng),
  );
}



