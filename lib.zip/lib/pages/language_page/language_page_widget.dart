import '../../constant.dart';
import '/flutter/flutter_icon_button.dart';
import '/flutter/flutter_theme.dart';
import '/flutter/flutter_util.dart';
import '/flutter/flutter_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'language_page_model.dart';
export 'language_page_model.dart';

class LanguagePageWidget extends StatefulWidget {
  const LanguagePageWidget({Key? key}) : super(key: key);

  @override
  _LanguagePageWidgetState createState() => _LanguagePageWidgetState();
}

class _LanguagePageWidgetState extends State<LanguagePageWidget> {
  late LanguagePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LanguagePageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterTheme.of(context).primaryBackground,
        // appBar: AppBar(
        //   backgroundColor: FlutterTheme.of(context).secondaryBackground,
        //   automaticallyImplyLeading: false,
        //   leading: FlutterIconButton(
        //     borderColor: Colors.transparent,
        //     borderRadius: 30.0,
        //     borderWidth: 1.0,
        //     buttonSize: 60.0,
        //     icon: Icon(
        //       Icons.arrow_back,
        //       color: FlutterTheme.of(context).primaryText,
        //       size: 30.0,
        //     ),
        //     onPressed: () async {
        //       context.pop();
        //     },
        //   ),
        //   title: Text(
        //     FFLocalizations.of(context).getText(
        //       'n64id622' /* Language */,
        //     ),
        //     style: FlutterTheme.of(context).headlineMedium.override(
        //           fontFamily: 'Urbanist',
        //           color: FlutterTheme.of(context).primaryText,
        //           fontSize: 22.0,
        //         ),
        //   ),
        //   actions: [],
        //   centerTitle: true,
        //   elevation: 2.0,
        // ),
        appBar: AppBar(
          backgroundColor: FlutterTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: InkWell(
            onTap: () {
              Helper.popScreen(context);
            },
            child: Padding(
              padding: const EdgeInsets.only(left: 10.0,top: 15,right: 0,bottom: 10),
              child: Image.asset('assets/images/back_icon_with_bg.png',height: 30,width: 30,),
            ),
          ),
          title: Text(
    FFLocalizations.of(context).getText(
          'n64id622' /* Language */,
        ),
            style: FlutterTheme.of(context).headlineMedium.override(
                fontFamily: 'Urbanist',
                color: FlutterTheme.of(context).primaryText,
                fontSize: 18.0,fontWeight: FontWeight.w600
            ),
          ),
          actions: [],
          centerTitle: false,
          // elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 8.0, 8.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                FFButtonWidget(
                  onPressed: () async {
                    setAppLanguage(context, 'en');
                    context.safePop();
                  },
                  text: FFLocalizations.of(context).getText(
                    'lu5f2dgm' /* English */,
                  ),
                  options: FFButtonOptions(
                     color: Colors.white,
                    height: 50.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    // color: FlutterTheme.of(context).primaryBtnText,
                    textStyle: FlutterTheme.of(context).titleSmall.override(
                          fontFamily: 'Urbanist',
                           color: Colors.black,
                          fontWeight: FontWeight.w400,
                      fontSize: 14
                        ),
                     elevation: 0.0,
                    borderSide: BorderSide(
                      color: FlutterTheme.of(context).alternatenew,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                FFButtonWidget(
                  onPressed: () async {
                    setAppLanguage(context, 'ar');
                    context.safePop();
                  },
                  text: FFLocalizations.of(context).getText(
                    '0ike59t8' /* Arabic */,
                  ),
                  options: FFButtonOptions(
                    height: 50.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: Colors.white,
                    textStyle: FlutterTheme.of(context).titleSmall.override(
                          fontFamily: 'Urbanist',
                          color: Colors.black,
                          fontWeight: FontWeight.w400,
                        ),
                    elevation: 0.0,
                    borderSide: BorderSide(
                      color: FlutterTheme.of(context).alternatenew,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                FFButtonWidget(
                  onPressed: () async {
                    setAppLanguage(context, 'es');
                    context.safePop();
                  },
                  text: FFLocalizations.of(context).getText(
                    '19zferan' /* Spanish */,
                  ),
                  options: FFButtonOptions(
                    height: 50.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(24.0, 0.0, 24.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: Colors.white,
                    textStyle: FlutterTheme.of(context).titleSmall.override(
                          fontFamily: 'Urbanist',
                          color: Colors.black,
                          fontWeight: FontWeight.w400,
                        ),
                    elevation: 0.0,
                    borderSide: BorderSide(
                      color: FlutterTheme.of(context).alternatenew,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ].divide(SizedBox(height: 16.0)),
            ),
          ),
        ),
      ),
    );
  }
}
