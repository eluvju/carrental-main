import '/flutter/flutter_animations.dart';
import '/flutter/flutter_theme.dart';
import '/flutter/flutter_util.dart';
import 'mode_screen_widget.dart' show ModeScreenWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModeScreenModel extends FlutterModel<ModeScreenWidget> {
  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
