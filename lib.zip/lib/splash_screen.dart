import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';

import 'app_state.dart';
import 'constant.dart';
import 'flutter/flutter_util.dart';
import 'flutter/nav/nav.dart';
import 'onbording_screen_first.dart';

class SpashScreen extends StatefulWidget {
  const SpashScreen({Key? key}) : super(key: key);

  @override
  State<SpashScreen> createState() => _SpashScreenState();
}


class _SpashScreenState extends State<SpashScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(milliseconds: 5000));
      // await Future.delayed(const Duration(minutes: 60));
      FFAppState().UserId != ''?   context.goNamed(
        'HomePage',
        extra: <String, dynamic>{
          kTransitionInfoKey: TransitionInfo(
            hasTransition: true,
            transitionType: PageTransitionType.fade,
            duration: Duration(milliseconds: 0),
          ),
        },
      ):
      Helper.moveToScreenwithPush(context, OnboardingScreen());
      // SessionHelper sessionHelper = await SessionHelper.getInstance(context);
      // var userId = sessionHelper.get(SessionHelper.USER_ID);
      // var user_type = sessionHelper.get(SessionHelper.USERTYPE);
      //
      // if (userId == null||userId =="0") {
      //   context.pushNamed('WelcomePage');
      // }
      // else if(user_type=="2"){
      //
      //   Helper.moveToScreenwithPush(context, FindGigsClass());
      //   // context.pushNamed(
      //   //   'CruzerHomePage',
      //   //   extra: <String, dynamic>{
      //   //     kTransitionInfoKey: TransitionInfo(
      //   //       hasTransition: true,
      //   //       transitionType: PageTransitionType.fade,
      //   //       duration: Duration(milliseconds: 0),
      //   //     ),
      //   //   },
      //   // );
      // }
      // else {
      //   context.pushNamed(
      //     'UserHomePage',
      //     extra: <String, dynamic>{
      //       kTransitionInfoKey: TransitionInfo(
      //         hasTransition: true,
      //         transitionType: PageTransitionType.fade,
      //         duration: Duration(milliseconds: 0),
      //       ),
      //     },
      //   );
      // }

    });
  }
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Stack(
          children: [
            Container(
                width: double.infinity,
                height: double.infinity,
                child: Image.asset(
                  'assets/images/splash-min.jpg',
                  fit: BoxFit.cover,
                )),
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              color: Color(0xff553FA5).withOpacity(0.75),
            ),
            Align(
              alignment: Alignment.center,
              child: SvgPicture.asset(
                     'assets/images/car_rental.svg',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
